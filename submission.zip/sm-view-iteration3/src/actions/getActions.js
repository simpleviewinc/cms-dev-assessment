// export function getResource(resource) {
//     req.get(`https://sv-reqres.now.sh/api/${resource}/?per_page=9`)
//         .then(response => {
//             let tileContainers = [];
//             let resLength = response.data.data.length
//             for(let i = 0; i<resLength; i+=3) {
//                 tileContainers.push(<TileContainer key={`tileConts${i}`} elementData={response.data.data.splice(0, 3)} />)
//             }  
//             console.log(tileContainers);
//             this.setState({data: tileContainers});
//         });
// }

import axios from 'axios';

export function getEvents() {
    return (dispatch) => {
        let url = 'https://sv-reqres.now.sh/api/events/?per_page=9';
        axios.get(url)
            .then(response => {
                dispatch({
                    type: 'GET_EVENTS',
                    payload: response.data,
                });
                console.log('DATA:', response.data);
        });
    }
}
export function getOffers() {
    return (dispatch) => {
        let url = 'https://sv-reqres.now.sh/api/offers/?per_page=9';
        axios.get(url)
            .then(response => {
                dispatch({
                    type: 'GET_OFFERS',
                    payload: response.data,
                });
        });
    }
}
export function getListings() {
    return (dispatch) => {
        let url = 'https://sv-reqres.now.sh/api/listings/?per_page=9';
        axios.get(url)
            .then(response => {
                dispatch({
                    type: 'GET_LISTINGS',
                    payload: response.data,
                });
        });
    }
}

export function changeView(view) {
    return {
        type: "CHANGE_VIEW",
        payload: view    
    };
}