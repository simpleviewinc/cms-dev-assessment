let initialState = {
    events: [],
    offers: [],
    listings: [],
    view: "all"
}

export default (state = initialState, action) => {
    let newState = Object.assign({}, state);
    switch(action.type) {
        case 'GET_EVENTS':
            newState.events = action.payload;
            return newState;
        case 'GET_OFFERS':
            newState.offers = action.payload;
            return newState;
        case 'GET_LISTINGS':
            newState.listings = action.payload;
            return newState;
        case 'CHANGE_VIEW':
            newState.view = action.payload;
            return newState;
        default:
            return newState;
    }
}