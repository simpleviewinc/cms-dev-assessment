import React, { Component } from 'react';
import Tile from './tile';
import { connect } from 'react-redux';

class TileContainer extends Component {

    getTiles() {
        console.log("called");
        const { events, listings, offers, filter } = this.props;
        // let eventTiles = events;
        // let offersTiles = offers;
        // let listingsTiles = listings;
        let allData = [];
        let listingsData = [];
        let offersData = [];
        let eventsData = [];

        console.log("Filter is ", filter);

        if(listings.data && filter === "listings") {
            listings.data.forEach(element => {
                allData.push(element);
                listingsData.push(element);
            });
        }

        else if (events.data && filter === "events") {
            events.data.forEach(element => {
                allData.push(element); 
                offersData.push(element);
            });
        }

        else if(offers.data && filter === "offers") {
            offers.data.forEach(element => {
                allData.push(element);
                eventsData.push(element);
            });
        }

        else if (listings.data && offers.data && events.data) {
            listings.data.forEach(element => {
                allData.push(element);
            });
            events.data.forEach(element => {
                allData.push(element); 
            });
            offers.data.forEach(element => {
                allData.push(element);
            });
        }
        

        console.log("All Data is: ",allData);

        // if(listings.data && offers.data && events.data && view === "all"){
        //     allData.push(listingsTiles);
        //     allData.push(offersTiles);
        //     allData.push(eventTiles);
        // }
        
        // const arrayMap = {
        //     listings: listingsTiles,
        //     events: eventTiles,
        //     offers: offersTiles,
        //     all: allData
        // }
        console.log(listingsData.length);
        console.log(offersData.length);
        console.log(eventsData.length);
        

        if(listingsData.length > 0) {
            let tileContainers = [];
            let resLength = listingsData.length;
            for(let i = 0; i<resLength; i+=3) {
                let temp = listingsData.splice(0,3);
                console.log("Temp Map View",temp);
                tileContainers.push(<div className="tile-container">
                    <Tile key={temp[0].recId}
                        tileTitle={temp[0].title}
                        tileImage={temp[0].mediaurl}
                        tileContent={temp[0].description}
                        tileClass={i % 6 === 1 ?  "tile-large" : "tile"}/>
                    <Tile key={temp[1].recId}
                        tileTitle={temp[1].title}
                        tileImage={temp[1].mediaurl}
                        tileContent={temp[1].description}
                        tileClass="small-tile"/>
                    <Tile key={temp[2].recId}
                        tileTitle={temp[2].title}
                        tileImage={temp[2].mediaurl}
                        tileContent={temp[2].description}
                        />
                    </div>)
            }
            return tileContainers;
        }

        if(eventsData.length > 0) {
            let tileContainers = [];
            let resLength = eventsData.length;
            for(let i = 0; i<resLength; i+=3) {
                let temp = eventsData.splice(0,3);
                tileContainers.push(<div className="tile-container">
                    <Tile key={temp[0].recId}
                        tileTitle={temp[0].title}
                        tileImage={temp[0].mediaurl}
                        tileContent={temp[0].description}
                        tileClass={i % 6 === 1 ?  "tile-large" : "tile"}/>
                    <Tile key={temp[1].recId}
                        tileTitle={temp[1].title}
                        tileImage={temp[1].mediaurl}
                        tileContent={temp[1].description}
                        tileClass="small-tile"/>
                    <Tile key={temp[2].recId}
                        tileTitle={temp[2].title}
                        tileImage={temp[2].mediaurl}
                        tileContent={temp[2].description}
                        />
                    </div>)
            }
            return tileContainers;
        }

        if(offersData.length > 0) {
            let tileContainers = [];
            let resLength = offersData.length;
            for(let i = 0; i<resLength; i+=3) {
                let temp = offersData.splice(0,3);
                tileContainers.push(<div className="tile-container">
                    <Tile key={temp[0].recId}
                        tileTitle={temp[0].title}
                        tileImage={temp[0].mediaurl}
                        tileContent={temp[0].description}
                        tileClass={i % 6 === 1 ?  "tile-large" : "tile"}/>
                    <Tile key={temp[1].recId}
                        tileTitle={temp[1].title}
                        tileImage={temp[1].mediaurl}
                        tileContent={temp[1].description}
                        tileClass="small-tile"/>
                    <Tile key={temp[2].recId}
                        tileTitle={temp[2].title}
                        tileImage={temp[2].mediaurl}
                        tileContent={temp[2].description}
                        />
                    </div>)
            }
            return tileContainers;
        }
        else {
            let tileContainers = [];
            let resLength = allData.length;
            for(let i = 0; i<resLength; i+=3) {
                let temp = allData.splice(0,3);
                tileContainers.push(<div className="tile-container">
                    <Tile key={temp[0].recId}
                        tileTitle={temp[0].title}
                        tileImage={temp[0].mediaurl}
                        tileContent={temp[0].description}
                        tileClass={i % 6 === 1 ?  "tile-large" : "tile"}/>
                    <Tile key={temp[1].recId}
                        tileTitle={temp[1].title}
                        tileImage={temp[1].mediaurl}
                        tileContent={temp[1].description}
                        tileClass="small-tile"/>
                    <Tile key={temp[2].recId}
                        tileTitle={temp[2].title}
                        tileImage={temp[2].mediaurl}
                        tileContent={temp[2].description}
                        />
                    </div>)
            }
            return tileContainers;
        }
    }
    render () {
        return (
            <React.Fragment>
                {this.getTiles()}
            </React.Fragment>
        );
    }
}

// const defaultProps = {
//     events: [],
//     offers: [],
//     listings: [],
//     filter: 'ALL',
// }

const mapStateToProps = state => {
    return {
        view: state.view
    }
}

export default connect(mapStateToProps)(TileContainer);