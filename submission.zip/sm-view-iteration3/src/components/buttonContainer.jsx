import React, { Component } from 'react';
import * as actions from '../actions/getActions';
import { connect } from 'react-redux';

class ButtonContainer extends Component {
    changeView = view => () => {this.props.changeView(view);}
    changeFilter = (e) => {
        this.props.changeFilter(e.target.name);
        console.log("Clicked" , e.target.name);
    }
    render () {
        return(
            <div className="button-container">
                {/* <button onClick={this.changeView("all")} type="button" className="btn btn-primary">All</button>
                <button onClick={this.changeView("listings")} type="button" className="btn btn-primary">Listings</button>
                <button onClick={this.changeView("events")} type="button" className="btn btn-primary">Events</button>
                <button onClick={this.changeView("offers")} type="button" className="btn btn-primary">Offers</button>
                 */}
                <button name="all" onClick={this.changeFilter} type="button" className="btn btn-primary">All</button>
                <button name="listings" onClick={this.changeFilter} type="button" className="btn btn-primary">Listings</button>
                <button name="events" onClick={this.changeFilter} type="button" className="btn btn-primary">Events</button>
                <button name="offers" onClick={this.changeFilter} type="button" className="btn btn-primary">Offers</button>
            </div>
        );
    }
}
const mapDispatchToProps = dispatch => {
    return {
        changeView: actions.changeView     
    }
}
export default connect(null, mapDispatchToProps)(ButtonContainer);