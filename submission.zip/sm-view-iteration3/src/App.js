import React, { Component } from 'react';
import './App.css';
import ButtonContainer from './components/buttonContainer';
import TileContainer from './components/tileContainer';
import { connect } from 'react-redux';
import * as actions from './actions/getActions';
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
        filter: 'all',
    }
  }

  changeFilter = (value) => {
    this.setState({filter: value});
  }
  componentDidMount(){
    this.props.getOffers();
    this.props.getEvents();
    this.props.getListings();
  }
    
  render() {
    return (
     <div className="app-container">
        <ButtonContainer
          changeFilter={this.changeFilter}
        />
            <TileContainer
              events={this.props.events}
              offers={this.props.offers}
              listings={this.props.listings}
              filter={this.state.filter}
            />
     </div>
    );
  }
}

let mapStateToProps = (state) => {
  return {
    listings: state.listings,
    events: state.events,
    offers: state.offers,
  }
}

let mapDispatchToProps = (dispatch) => {
  return {
    getOffers: () => dispatch(actions.getOffers()),
    getEvents: () => dispatch(actions.getEvents()),
    getListings: () => dispatch(actions.getListings()),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
