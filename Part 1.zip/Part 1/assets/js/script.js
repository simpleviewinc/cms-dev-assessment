// api url 
const api_url =  
      "https://sv-reqres.now.sh/api/listings"; 
  
// Defining async function 
async function getapi() { 
    
    // Storing response 
    const response = await fetch(api_url); 
    
    // Storing data in form of JSON 
    const info = await response.json(); 
    if (response) { 
        hideloader(); 
    } 
    return info.data; 
} 
// Calling that async function 
getapi(api_url); 
  
// Function to hide the loader 
function hideloader() { 
    document.getElementById('loading').style.display = 'none'; 
} 
// Function to define innerHTML for HTML table 
async function show() {

    const data = await getapi();
    const tab = data
    .map((content, index) => 
            `<div class="content${index}">
                <img src="${content.mediaurl}" onerror='this.onerror = null; this.src="./assets/images/fallback.jpg"' alt="Photo of listing" class="image${index}"></img>
                <div class="enclose enclose${index}">
                    <h2>${content.title}</h2>
                    <p class="description description${index}">${content.description}</p>
                </div>
            </div>`
        )
        .join("");
        
    // Setting innerHTML as tab variable 
    document.querySelector(".apiData").innerHTML = tab; 
} 

show();