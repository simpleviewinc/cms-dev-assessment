let buttonValue;

//change API based on value of the button
const button = document.querySelectorAll(".button").forEach(
  button => button.addEventListener('click', function(e) {
    buttonValue = e.target.value;
    api_url = `https://sv-reqres.now.sh/api/${buttonValue}`;

    //Set button as active on click
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";

    getApi();
    show();
    })
)
  
// Defining async function 
async function getApi() { 
    
    // Storing response 
    const response = await fetch(api_url); 
    
    // Storing data in form of JSON 
    const info = await response.json(); 
    if (response) { 
        hideloader(); 
    } 
    return info.data; 
}
  
// Function to hide the loader 
function hideloader() { 
    document.getElementById('loading').style.display = 'none'; 
} 

// Function to add JSON data to HTML and display it
async function show() {

    const data = await getApi();
    const tab = data
    .map((content, index) => 
            `<div class="content${index}">
                <img src="${content.mediaurl}" onerror='this.onerror = null; this.src="./assets/images/fallback.jpg"' alt="Photo of listing" class="image${index}"></img>
                <div class="enclose enclose${index}">
                    <h2>${content.title}</h2>
                    <p class="description description${index}">${content.description}</p>
                    <button class="btn">Read More</button>
                </div>
            </div>`
        )
        .join("");

    document.querySelector(".apiData").innerHTML = tab; 
}

function allApi() {
    Promise.all([
        fetch('https://sv-reqres.now.sh/api/listings'),
        fetch('https://sv-reqres.now.sh/api/events'),
        fetch('https://sv-reqres.now.sh/api/offers')
    ]).then(function (responses) {
        // Get a JSON object from each of the responses
        return Promise.all(responses.map(function (response) {
            return response.json();
        }));
    }).then(function (data) {
        
        //combine data from json arrays
        let info = data[0].data.concat(data[1].data, data[2].data);

        const tab = info
        .map((content, index) => 
            `<div class="content${index}">
                <img src="${content.mediaurl}" onerror='this.onerror = null; this.src="./assets/images/fallback.jpg"' alt="Photo of listing" class="image${index}"></img>
                <div class="enclose enclose${index}">
                    <h2>${content.title}</h2>
                    <p class="description description${index}">${content.description}</p>
                    <button class="btn">Read More</button>
                </div>
            </div>`
        )
        .join("");

        document.querySelector(".apiData").innerHTML = tab;
    })

    document.getElementById("button1").classList.remove("active");
    document.getElementById("button2").classList.remove("active");
    document.getElementById("button3").classList.remove("active");
    document.getElementById("initial").classList.add("active");
}

// Calling get async function 
allApi();
show();